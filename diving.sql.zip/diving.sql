-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2021 at 12:12 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `diving`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `photo`, `banner`, `status`, `created_at`, `updated_at`) VALUES
(1, '1617146070.jpg', '1617146071.jpg', 1, '2021-03-30 21:14:31', '2021-03-30 21:15:13');

-- --------------------------------------------------------

--
-- Table structure for table `about_translations`
--

CREATE TABLE `about_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `about_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_translations`
--

INSERT INTO `about_translations` (`id`, `locale`, `about_id`, `title`, `slug`, `description`, `metaData`, `metaDescription`, `keywords`) VALUES
(1, 'en', 1, 'Diving', 'diving', '<p>Egypt&rsquo;s reefs are teeming with life; bright corals and clouds of fish dazzle with a kaleidoscope of colour. With wonderfully calm and clear conditions, Egyptian reefs offer ideal conditions for new divers, marine life enthusiasts, wreck divers or anyone simply interested in exploring light-filled reef systems.</p>', 'Diving', 'Diving', 'Diving');

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `photo`, `banner`, `status`, `created_at`, `updated_at`) VALUES
(1, '1617142224.jpg', '1617142225.jpg', 1, '2021-03-30 20:10:25', '2021-03-30 20:10:29');

-- --------------------------------------------------------

--
-- Table structure for table `activity_translations`
--

CREATE TABLE `activity_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_translations`
--

INSERT INTO `activity_translations` (`id`, `locale`, `activity_id`, `title`, `slug`, `description`, `metaData`, `metaDescription`, `keywords`) VALUES
(1, 'en', 1, 'Diving', 'diving', '<p>Egypt&rsquo;s reefs are teeming with life; bright corals and clouds of fish dazzle with a kaleidoscope of colour. With wonderfully calm and clear conditions, Egyptian reefs offer ideal conditions for new divers, marine life enthusiasts, wreck divers or anyone simply interested in exploring light-filled reef systems.</p>', 'Diving', 'Diving', 'Diving');

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `album_translations`
--

CREATE TABLE `album_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `album_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `course_id` bigint(20) UNSIGNED DEFAULT NULL,
  `trip_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `first`, `last`, `email`, `number`, `course_id`, `trip_id`, `created_at`, `updated_at`) VALUES
(1, 'Wasila', 'Mohamed', 'wasilamhmd@gmail.com', 120000, 2, NULL, '2021-03-30 19:38:09', '2021-03-30 19:38:09');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `offer` int(11) DEFAULT NULL,
  `duration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `photo`, `banner`, `video`, `price`, `offer`, `duration`, `status`, `created_at`, `updated_at`) VALUES
(1, '1617134996.jpg', '1617134996.jpg', NULL, 950, NULL, '3 hours', 1, '2021-03-30 18:09:56', '2021-03-30 18:10:02'),
(2, '1617135155.jpg', '1617135155.jpg', NULL, 5600, 5200, '2 days', 1, '2021-03-30 18:12:35', '2021-03-30 18:12:39'),
(3, '1617616684.jpg', '1617616686.jpg', NULL, 2382, 2191, '4 hours', 1, '2021-04-05 07:58:04', '2021-04-05 07:58:11');

-- --------------------------------------------------------

--
-- Table structure for table `course_translations`
--

CREATE TABLE `course_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requirements` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course_translations`
--

INSERT INTO `course_translations` (`id`, `locale`, `course_id`, `title`, `slug`, `description`, `languages`, `requirements`, `metaData`, `metaDescription`, `keywords`) VALUES
(1, 'en', 1, 'DISCOVER SCUBA DIVING', 'discover-scuba-diving', '<p><strong>Have you always wondered what it&rsquo;s like to breathe underwater? If you want to try scuba diving, but aren&rsquo;t quite ready to take the plunge into a certification course, Discover Scuba Diving is for you.</strong></p>\r\n\r\n<ul>\r\n	<li>A quick and easy introduction into what it takes to explore the underwater world</li>\r\n	<li>Breathe underwater for the first time (something you&rsquo;ll never forget)</li>\r\n	<li>Have fun swimming around and exploring (while you learn key skills that you&rsquo;ll use during every scuba dive)</li>\r\n</ul>', 'English Italic Russian', 'Minimum age: 10+\r\nMin. certification: None\r\nNo prior experience with scuba diving is necessary, but you need to be in reasonable physical health.', 'DISCOVER SCUBA DIVING', 'DISCOVER SCUBA DIVING', 'DISCOVER SCUBA DIVING'),
(2, 'en', 2, 'OPEN WATER DIVER', 'open-water-diver', '<p><strong>Advance your diving skills! After having taken this course, you will be allowed to dive down to 30 metres/100 feet and will have learnt invaluable skills such as underwater navigation, night diving or wreck diving. 5 adventure dives included.</strong></p>\r\n\r\n<ul>\r\n	<li>Expand and deepen your knowledge, ability and confidence to enjoy the underwater world</li>\r\n	<li>Learn to deal with the physiological effects and challenges of deeper scuba diving - and get to grips with the thrills it offers</li>\r\n	<li>Tailor learning and dives to your interests, including fish identification, buoyancy control, wreck diving and more</li>\r\n</ul>', 'English Italic Russian', 'Minimum age: 12+\r\nMin. certification: Open Water Certification required', 'OPEN WATER DIVER', 'OPEN WATER DIVER', 'OPEN WATER DIVER'),
(3, 'en', 3, 'DISCOVER SCUBA DIVING', 'discover-scuba-diving-1', '<p><strong>Discover the magic and beauty of Dahab&#39;s coral reefs on this special introduction to scuba diving. Over two dives you will learn basic scuba safety skills &quot;1-2-1&quot; with your instructor. Max depth is 12 meters, fun is unlimited!</strong></p>\r\n\r\n<ul>\r\n	<li>Breathe underwater</li>\r\n	<li>Visit the reef</li>\r\n	<li>Beautiful coral</li>\r\n</ul>', 'English Russian Italian', 'Minimum age: 10+\r\nMin. certification: None', 'DISCOVER SCUBA DIVING', 'DISCOVER SCUBA DIVING', 'DISCOVER SCUBA DIVING');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `levels`
--

CREATE TABLE `levels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `level_translations`
--

CREATE TABLE `level_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(10) UNSIGNED NOT NULL,
  `disk` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `directory` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `disk`, `directory`, `filename`, `extension`, `mime_type`, `aggregate_type`, `size`, `created_at`, `updated_at`) VALUES
(2, 'uploads', '', 'discoverScuba2-2', 'jpg', 'image/jpeg', 'image', 229209, '2021-03-30 18:09:58', '2021-03-30 18:09:58'),
(3, 'uploads', '', 'waterDiver1-1', 'jpg', 'image/jpeg', 'image', 147200, '2021-03-30 18:12:36', '2021-03-30 18:12:36'),
(4, 'uploads', '', 'waterDiver2-1', 'jpg', 'image/jpeg', 'image', 149183, '2021-03-30 18:12:36', '2021-03-30 18:12:36'),
(5, 'uploads', '', 'waterDiver3', 'jpg', 'image/jpeg', 'image', 113815, '2021-03-30 18:12:36', '2021-03-30 18:12:36'),
(8, 'uploads', '', 'discoverScuba1-3', 'jpg', 'image/jpeg', 'image', 114659, '2021-03-30 18:21:27', '2021-03-30 18:21:27'),
(9, 'uploads', '', 'Discover_Scuba_Diving_--_St._Croix,_US_Virgin_Islands', 'jpg', 'image/jpeg', 'image', 97179, '2021-03-30 18:30:34', '2021-03-30 18:30:34'),
(10, 'uploads', '', 'snorkilling1-3-2', 'jpg', 'image/jpeg', 'image', 45371, '2021-03-30 20:32:17', '2021-03-30 20:32:17'),
(11, 'uploads', '', 'snorkillng1-2-1', 'jpg', 'image/jpeg', 'image', 31809, '2021-03-30 20:32:17', '2021-03-30 20:32:17'),
(12, 'uploads', '', '7068dc3656308e47e94ee1399444b1af', 'jpg', 'image/jpeg', 'image', 195625, '2021-04-05 07:58:07', '2021-04-05 07:58:07'),
(13, 'uploads', '', 'a92b4b98b491d076fe845add8d8cc35f', 'jpg', 'image/jpeg', 'image', 221734, '2021-04-05 07:58:07', '2021-04-05 07:58:07'),
(14, 'uploads', '', 'adc00306db98197d7142c4e89e9baabd', 'jpg', 'image/jpeg', 'image', 239128, '2021-04-05 07:58:08', '2021-04-05 07:58:08'),
(15, 'uploads', '', 'radm', 'jpg', 'image/jpeg', 'image', 241082, '2021-04-05 08:02:49', '2021-04-05 08:02:49'),
(16, 'uploads', '', 'rasm2', 'jpg', 'image/jpeg', 'image', 135438, '2021-04-05 08:02:49', '2021-04-05 08:02:49'),
(17, 'uploads', '', '3ff404b653e64c4be5beee4be290cdeb', 'jpg', 'image/jpeg', 'image', 204586, '2021-04-05 08:07:14', '2021-04-05 08:07:14'),
(18, 'uploads', '', '59b79b7001ed30142b42e847c620bb38', 'jpg', 'image/jpeg', 'image', 171522, '2021-04-05 08:07:14', '2021-04-05 08:07:14'),
(19, 'uploads', '', '3968d5bae86f7781e5a2e057fa15af21', 'jpg', 'image/jpeg', 'image', 229894, '2021-04-05 08:07:14', '2021-04-05 08:07:14');

-- --------------------------------------------------------

--
-- Table structure for table `mediables`
--

CREATE TABLE `mediables` (
  `media_id` int(10) UNSIGNED NOT NULL,
  `mediable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mediable_id` int(10) UNSIGNED NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mediables`
--

INSERT INTO `mediables` (`media_id`, `mediable_type`, `mediable_id`, `tag`, `order`) VALUES
(3, 'App\\Models\\Course', 2, 'course', 1),
(10, 'App\\Models\\Trip', 2, 'trip', 1),
(12, 'App\\Models\\Course', 3, 'course', 1),
(15, 'App\\Models\\Trip', 3, 'trip', 1),
(17, 'App\\Models\\Trip', 4, 'trip', 1),
(2, 'App\\Models\\Course', 1, 'course', 2),
(4, 'App\\Models\\Course', 2, 'course', 2),
(8, 'App\\Models\\Trip', 1, 'trip', 2),
(11, 'App\\Models\\Trip', 2, 'trip', 2),
(13, 'App\\Models\\Course', 3, 'course', 2),
(16, 'App\\Models\\Trip', 3, 'trip', 2),
(18, 'App\\Models\\Trip', 4, 'trip', 2),
(5, 'App\\Models\\Course', 2, 'course', 3),
(9, 'App\\Models\\Trip', 1, 'trip', 3),
(14, 'App\\Models\\Course', 3, 'course', 3),
(19, 'App\\Models\\Trip', 4, 'trip', 3);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(20, '2014_10_12_000000_create_users_table', 1),
(21, '2014_10_12_100000_create_password_resets_table', 1),
(22, '2019_08_19_000000_create_failed_jobs_table', 1),
(23, '2021_03_22_205346_create_mediable_tables', 1),
(24, '2021_03_22_210153_create_abouts_table', 1),
(25, '2021_03_22_210220_create_about_translations_table', 1),
(26, '2021_03_22_210251_create_courses_table', 1),
(27, '2021_03_22_210323_create_course_translations_table', 1),
(28, '2021_03_22_210340_create_trips_table', 1),
(29, '2021_03_22_210356_create_trip_translations_table', 1),
(30, '2021_03_22_210429_create_albums_table', 1),
(31, '2021_03_22_210444_create_places_table', 1),
(32, '2021_03_22_210502_create_place_translations_table', 1),
(33, '2021_03_22_210518_create_settings_table', 1),
(34, '2021_03_22_211157_create_album_translations_table', 1),
(35, '2021_03_24_143532_create_levels_table', 1),
(36, '2021_03_24_143609_create_level_translations_table', 1),
(37, '2021_03_24_143651_create_activities_table', 1),
(38, '2021_03_24_143718_create_activity_translations_table', 1),
(39, '2021_03_30_143858_create_bookings_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE `places` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `photo`, `banner`, `status`, `created_at`, `updated_at`) VALUES
(1, '1617143094.jpg', '1617143095.jpg', 1, '2021-03-30 20:24:55', '2021-03-30 20:25:04'),
(2, '1617143143.jpg', '1617143143.jpg', 1, '2021-03-30 20:25:43', '2021-03-30 20:25:48'),
(3, '1617143190.jpg', '1617143190.jpg', 1, '2021-03-30 20:26:30', '2021-03-30 20:26:34');

-- --------------------------------------------------------

--
-- Table structure for table `place_translations`
--

CREATE TABLE `place_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `place_translations`
--

INSERT INTO `place_translations` (`id`, `locale`, `place_id`, `title`, `slug`, `description`, `metaData`, `metaDescription`, `keywords`) VALUES
(1, 'en', 1, 'Ras Mohammed National Park', 'ras-mohammed-national-park', '<p>Ras Mohammed National Park is what put Sharm el-Sheikh on the tourist map. Surrounded by some of the world&#39;s most incredible dive sites, this peninsula is home to glorious beaches with excellent snorkeling just offshore, the world&#39;s second most northerly&nbsp;<strong>mangrove forest</strong>, and a&nbsp;<strong>saltwater lake</strong>. A trip here is a must-do for anyone staying in Sharm el-Sheikh. The best beaches are&nbsp;<strong>Old Quay Beach</strong>&nbsp;(with its top-notch coral reef easily reached from the shore) and&nbsp;<strong>Aqaba Beach</strong>.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Travelers seeking a good view should head to the&nbsp;<strong>Shark Observatory cliff top</strong>&nbsp;right on the southern edge of Ras Mohammed, where views stretch across both sides of the Red Sea.</p>\r\n\r\n<p>Location: 38 kilometers south of Sharm el-Sheikh</p>', 'Ras Mohammed National Park', 'Ras Mohammed National Park', 'Ras Mohammed National Park'),
(2, 'en', 2, 'Thistlegorm Dive Site', 'thistlegorm-dive-site', '<p>For many advanced divers, a trip to Sharm el-Sheikh means only one thing: diving the Thistlegorm. One of the top wreck dives in the world, this ship packed full of cargo to resupply British troops was sunk during World War II by German bombers. Fish now flit through its rooms and cargo holds filled with jeeps, motorbikes, and armaments that never made it to the front. The wreck is situated in the Straits of Gubal, off the western coast of the Sinai Peninsula, so it is offered as either a long one-day boat trip from Sharm el-Sheikh or an overnight trip. All boat tours here offer at least two dives of the wreck plus a stop at one of Ras Mohammed&#39;s dive sites. The overnight trips have the added bonus of a night dive of the wreck.</p>', 'Thistlegorm Dive Site', 'Thistlegorm Dive Site', 'Thistlegorm Dive Site'),
(3, 'en', 3, 'Naama Bay', 'naama-bay', '<p>Fringed by a white-sand beach and swaying palm trees, Naama Bay is the epicenter of Sharm el-Sheikh&#39;s resort life. There are plentiful restaurants, caf&eacute;s, and souvenir stores if you get bored of the sand, but Naama Bay is really all about the beach. A pedestrian-only promenade rims the entire&nbsp;<strong>beach area</strong>, backed by a cluster of luxury resorts. For those looking for a holiday full of sloth-like sunbathing, Naama Bay is one of Egypt&#39;s top choices. The entire beach area has excellent facilities, including ample sun-shades and loungers, and the beachside caf&eacute;s mean you don&#39;t even have to move from your patch of sandy bliss all day.</p>', 'Naama Bay', 'Naama Bay', 'Naama Bay');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `data`, `created_at`, `updated_at`) VALUES
(1, 'CourseDescription', 'a:1:{s:11:\"description\";a:3:{s:2:\"en\";s:324:\"<p>Egypt&rsquo;s reefs are teeming with life; bright corals and clouds of fish dazzle with a kaleidoscope of colour. With wonderfully calm and clear conditions, Egyptian reefs offer ideal conditions for new divers, marine life enthusiasts, wreck divers or anyone simply interested in exploring light-filled reef systems.</p>\";s:2:\"it\";N;s:2:\"ru\";N;}}', NULL, '2021-03-30 19:42:27'),
(2, 'contact', 'a:3:{s:6:\"mobile\";s:6:\"552626\";s:5:\"email\";s:11:\"admin@admin\";s:7:\"address\";s:6:\"dddddd\";}', NULL, '2021-03-30 19:42:40'),
(3, 'footerBanner', 'a:2:{s:7:\"address\";a:3:{s:2:\"en\";s:8:\"MEGALDON\";s:2:\"it\";N;s:2:\"ru\";N;}s:11:\"description\";a:3:{s:2:\"en\";s:184:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s</p>\";s:2:\"it\";N;s:2:\"ru\";N;}}', NULL, '2021-03-30 19:51:17'),
(4, 'HomeBanner', 'a:2:{s:5:\"title\";a:3:{s:2:\"en\";s:8:\"MEGALDON\";s:2:\"it\";N;s:2:\"ru\";N;}s:11:\"description\";a:3:{s:2:\"en\";s:184:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s</p>\";s:2:\"it\";N;s:2:\"ru\";N;}}', NULL, '2021-03-30 19:46:59'),
(5, 'placesDescription', 'a:4:{s:7:\"address\";a:3:{s:2:\"en\";s:23:\"Discover our Top places\";s:2:\"it\";N;s:2:\"ru\";N;}s:11:\"description\";a:3:{s:2:\"en\";s:184:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s</p>\";s:2:\"it\";N;s:2:\"ru\";N;}s:9:\"linktitle\";a:3:{s:2:\"en\";s:9:\"Read more\";s:2:\"it\";N;s:2:\"ru\";N;}s:4:\"link\";a:3:{s:2:\"en\";N;s:2:\"it\";N;s:2:\"ru\";N;}}', NULL, '2021-03-30 19:51:49'),
(6, 'siteSetting', 'a:2:{s:7:\"address\";a:3:{s:2:\"en\";s:8:\"MEGALDON\";s:2:\"it\";N;s:2:\"ru\";N;}s:11:\"description\";a:3:{s:2:\"en\";s:184:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s</p>\";s:2:\"it\";N;s:2:\"ru\";N;}}', NULL, '2021-03-30 19:55:49'),
(7, 'SocialMedia', 'a:3:{s:8:\"facebook\";s:1:\"#\";s:8:\"instgram\";s:1:\"#\";s:7:\"twitter\";s:1:\"#\";}', NULL, '2021-03-30 19:56:06');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `offer` int(11) DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`id`, `photo`, `banner`, `video`, `price`, `offer`, `date`, `status`, `created_at`, `updated_at`) VALUES
(1, '1617135316.jpg', '1617135316.jpg', NULL, 477, NULL, '6 hours', 1, '2021-03-30 18:15:16', '2021-03-30 18:15:49'),
(2, '1617143536.jpg', '1617143536.jpg', NULL, 1048, 953, '1 day', 1, '2021-03-30 20:32:16', '2021-03-30 20:32:20'),
(3, '1617616968.jpg', '1617616968.jpg', NULL, 858, 667, '8 hours', 1, '2021-04-05 08:02:48', '2021-04-05 08:02:52'),
(4, '1617617233.jpg', '1617617233.jpg', NULL, 572, NULL, '8 hours', 1, '2021-04-05 08:07:13', '2021-04-05 08:07:17');

-- --------------------------------------------------------

--
-- Table structure for table `trip_translations`
--

CREATE TABLE `trip_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trip_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trip_translations`
--

INSERT INTO `trip_translations` (`id`, `locale`, `trip_id`, `title`, `slug`, `description`, `languages`, `metaData`, `metaDescription`, `keywords`) VALUES
(1, 'en', 1, 'FULL-DAY SNORKELLING TRIP', 'full-day-snorkelling-trip', '<p><strong>Sharm as a shore entry offers many snorkeling sites starts from the famous Blue Hole at the north end to the Caves at the south end.</strong></p>\r\n\r\n<ul>\r\n	<li>Leaving daily at 10 AM</li>\r\n	<li>Choosing the site will depend on sea conditions and experience</li>\r\n	<li>Only certified guides will be with you from a minimum snorkel guide up to open water scuba instructor</li>\r\n	<li>Your safety and satisfaction are our top priorities</li>\r\n</ul>', NULL, 'FULL-DAY SNORKELLING TRIP', 'FULL-DAY SNORKELLING TRIP', 'FULL-DAY SNORKELLING TRIP'),
(2, 'en', 2, 'BOAT TRIP TO GABR-EL-BINT NATIONAL PARK', 'boat-trip-to-gabr-el-bint-national-park', '<p><strong>A fantastic day trip to visit one of Dahab&#39;s best sites for fish and coral. Food and soft drinks included on our luxury boat. Great for diving, snorkeling or just swimming! Chance to spot dolphins!</strong></p>\r\n\r\n<ul>\r\n	<li>Enjoy some of the best marine life in Dahab</li>\r\n	<li>Great day on a luxury boat</li>\r\n	<li>Regular sightings of large marine life</li>\r\n	<li>Beautiful, colourful corals</li>\r\n	<li>Expert guides</li>\r\n</ul>', 'English Italic Russian', 'GABR-EL-BINT NATIONAL PARK', 'GABR-EL-BINT NATIONAL PARK', 'GABR-EL-BINT NATIONAL PARK'),
(3, 'en', 3, 'RAS MOHAMED SNORKEL EXCURSION', 'ras-mohamed-snorkel-excursion', '<p><strong>Explore the National Park of Ras Mohamed on board our award winning fleet. Enjoy snorkeling some of the best dive sites in the World where you will see marine life like never before!</strong></p>\r\n\r\n<ul>\r\n	<li>Discover Ras Mohamed Snorkeling</li>\r\n	<li>Enjoy a full day out on the sea on our award winning fleet</li>\r\n	<li>Enjoy a freshly prepared lunch on board</li>\r\n	<li>FREE Snorkeling Equipment</li>\r\n	<li>Explore the underwater world of the Red Sea</li>\r\n</ul>', 'English Russian italian', 'RAS MOHAMED SNORKEL', 'RAS MOHAMED SNORKEL', 'RAS MOHAMED SNORKEL'),
(4, 'en', 4, 'TIRAN ISLAND SNORKEL EXCURSION', 'tiran-island-snorkel-excursion', '<p><strong>Enjoy the Straits of Tiran Dive Sites whilst snorkeling. Here you can expect to see awesome marine life whilst exploring the Red Sea.</strong></p>\r\n\r\n<ul>\r\n	<li>Enjoy views of the Shipwreck clearly visible from the boat</li>\r\n	<li>Explore 3 seperate snorkel locations</li>\r\n	<li>Enjoy a delicious buffet lunch</li>\r\n	<li>Discover the wonders of the Red Sea with us</li>\r\n	<li>FREE Snorkel Equipment with this excursion</li>\r\n</ul>', 'English Russian Italian', 'TIRAN ISLAND SNORKEL', 'TIRAN ISLAND SNORKEL', 'TIRAN ISLAND SNORKEL');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Alvina Thiel', 'admin@admin.com', NULL, '$2y$10$zlN3PuSCSA70J3VJSiKWOuD3Dg4yXkYqxnl59VKxeyx1Co95hjvGy', 'q4d45hCcZADi3xadsCcbMYNCKfUfJbKiaOdA6zbNP2DWpWQUm2iGTDeDbsjb', '2021-03-30 17:58:19', '2021-03-30 17:58:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_translations`
--
ALTER TABLE `about_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `about_translations_about_id_locale_unique` (`about_id`,`locale`),
  ADD KEY `about_translations_locale_index` (`locale`);

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_translations`
--
ALTER TABLE `activity_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `activity_translations_activity_id_locale_unique` (`activity_id`,`locale`),
  ADD KEY `activity_translations_locale_index` (`locale`);

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `album_translations`
--
ALTER TABLE `album_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `album_translations_album_id_locale_unique` (`album_id`,`locale`),
  ADD KEY `album_translations_locale_index` (`locale`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookings_course_id_foreign` (`course_id`),
  ADD KEY `bookings_trip_id_foreign` (`trip_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_translations`
--
ALTER TABLE `course_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_translations_course_id_locale_unique` (`course_id`,`locale`),
  ADD KEY `course_translations_locale_index` (`locale`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `levels`
--
ALTER TABLE `levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `level_translations`
--
ALTER TABLE `level_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `level_translations_level_id_locale_unique` (`level_id`,`locale`),
  ADD KEY `level_translations_locale_index` (`locale`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media_disk_directory_filename_extension_unique` (`disk`,`directory`,`filename`,`extension`),
  ADD KEY `media_aggregate_type_index` (`aggregate_type`);

--
-- Indexes for table `mediables`
--
ALTER TABLE `mediables`
  ADD PRIMARY KEY (`media_id`,`mediable_type`,`mediable_id`,`tag`),
  ADD KEY `mediables_mediable_id_mediable_type_index` (`mediable_id`,`mediable_type`),
  ADD KEY `mediables_tag_index` (`tag`),
  ADD KEY `mediables_order_index` (`order`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `places`
--
ALTER TABLE `places`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `place_translations`
--
ALTER TABLE `place_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `place_translations_place_id_locale_unique` (`place_id`,`locale`),
  ADD KEY `place_translations_locale_index` (`locale`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip_translations`
--
ALTER TABLE `trip_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `trip_translations_trip_id_locale_unique` (`trip_id`,`locale`),
  ADD KEY `trip_translations_locale_index` (`locale`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `about_translations`
--
ALTER TABLE `about_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `activity_translations`
--
ALTER TABLE `activity_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `albums`
--
ALTER TABLE `albums`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `album_translations`
--
ALTER TABLE `album_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `course_translations`
--
ALTER TABLE `course_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `levels`
--
ALTER TABLE `levels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `level_translations`
--
ALTER TABLE `level_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `places`
--
ALTER TABLE `places`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `place_translations`
--
ALTER TABLE `place_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `trip_translations`
--
ALTER TABLE `trip_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `about_translations`
--
ALTER TABLE `about_translations`
  ADD CONSTRAINT `about_translations_about_id_foreign` FOREIGN KEY (`about_id`) REFERENCES `abouts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `activity_translations`
--
ALTER TABLE `activity_translations`
  ADD CONSTRAINT `activity_translations_activity_id_foreign` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `album_translations`
--
ALTER TABLE `album_translations`
  ADD CONSTRAINT `album_translations_album_id_foreign` FOREIGN KEY (`album_id`) REFERENCES `albums` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `bookings_trip_id_foreign` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`);

--
-- Constraints for table `course_translations`
--
ALTER TABLE `course_translations`
  ADD CONSTRAINT `course_translations_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `level_translations`
--
ALTER TABLE `level_translations`
  ADD CONSTRAINT `level_translations_level_id_foreign` FOREIGN KEY (`level_id`) REFERENCES `levels` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mediables`
--
ALTER TABLE `mediables`
  ADD CONSTRAINT `mediables_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `place_translations`
--
ALTER TABLE `place_translations`
  ADD CONSTRAINT `place_translations_place_id_foreign` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `trip_translations`
--
ALTER TABLE `trip_translations`
  ADD CONSTRAINT `trip_translations_trip_id_foreign` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
